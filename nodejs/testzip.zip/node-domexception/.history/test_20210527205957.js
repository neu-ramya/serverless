require('./index.js')

console.log(DOMException.INDEX_SIZE_ERR)
