/** @type {typeof globalThis.Blob} */
export const Blob: typeof globalThis.Blob;
export default Blob;
