/** @type {typeof globalThis.File} */ export const File: typeof globalThis.File;
export default File;
