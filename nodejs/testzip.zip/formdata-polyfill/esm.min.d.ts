export declare const FormData: {
  new (): FormData;
  prototype: FormData;
};
export declare function formDataToBlob(formData: FormData): Blob;
