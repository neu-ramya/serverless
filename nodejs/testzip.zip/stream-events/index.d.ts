import { Stream } from "stream";
declare function StreamEvents<StreamType extends Stream>(stream: StreamType)
  : StreamType;
declare namespace StreamEvents { }
export = StreamEvents
